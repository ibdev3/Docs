USE loja;


CREATE TABLE tabela_nao_normalizada(
	nome_cliente VARCHAR(100),
	telefone_cliente VARCHAR(100),
	telefone_cliente2 VARCHAR(100),
	pedido_produto VARCHAR(100),
	pedido_quantidade INTEGER(100),
	pedido_valor_produto REAL(10,2)
	);				


CREATE TABLE CLIENTE (
	id_cliente INTEGER PRIMARY KEY AUTO_INCREMENT,
	nome_cliente VARCHAR(100),
    telefone_cliente VARCHAR(100),
    pedido_produto VARCHAR(100),
    pedido_quantidade VARCHAR(100),
    pedido_valor_produto REAL(10,2)
    );
    
    
    INSERT INTO cliente VALUES(null, "Inacio Barros" , "(61) 984995360" , "celular" , 10, 99.99) ;
    
    INSERT INTO cliente VALUES(null,"Guilherme Campbell", "(61)98888-7777", "celular", 10, 999.99);
    
INSERT INTO CLIENTE VALUES(null, "Luis Romera", "(61)93344-4443", "livro", 8, 432.65);

INSERT INTO cliente VALUES(null, "Tudes Pereira", "(61)4402-8922", "computador", 5, 997.50);

INSERT INTO cliente VALUES(null, "Caio Oham","(61) 90900_8080","celular", 5, 800.98);

INSERT INTO cliente VALUES(null, "Guilherme Tierno", "(61)99808-1040", "PC", 10, 999.99);

INSERT INTO cliente VALUES(null, "Rodrigo", "(61)99999-8888", "celular", 10, 975.80);

INSERT INTO cliente VALUES(null, "Filipe Moura", "(61)98888-4848", "celular", 10, 889.99);

INSERT INTO cliente VALUE(null, "Lucas Davi", "(61)99506-9307", "iphone", 10, 999.99);

INSERT INTO cliente VALUES(null, "Davi Victor","(61) 90900_8080", 5, 800.98);

INSERT INTO  cliente VALUES(null,"Marcia Kamyla", "(61)99647-1456", "celular", 35, 562.33);

INSERT INTO cliente VALUES(null,"Daniele Pinheiro", "(61)998989898 ", "celular", 11, 999.99);

SELECT * FROM cliente;

INSERT INTO cliente (nome_cliente, telefone_cliente) VALUES ("Inácio Barros", "61 9 84995360" ) ; 

SELECT * FROM cliente;
SELECT * FROM cliente WHERE id_cliente = 3 ;  /* PARA PREOCURAR A PESSAO PELO ID, POREM ELE PREOCURA SOMENTE O ID EXATO */ 
SELECT * FROM cliente WHERE nome_cliente = "caio oham" ;   /* PARA PREOCURAR A PESSAO PELO NOME, PÓREM ELE PREOCURA SOMENTE O NOME EXATO */ 
SELECT count(*) FROM cliente ;  
SELECT count(*) FROM cliente WHERE nome_cliente = "Inacio" ;  



